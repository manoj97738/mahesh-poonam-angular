import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ContactComponent } from './contact/contact.component';
import { MyCutsompipe } from './mycustom.pipe';
import { AccountComponent } from './account/account.component';

import { Routes, RouterModule } from "@angular/router";
const myRoute: Routes = [
  { path: "", component: ContactComponent },
  { path: "account", component: AccountComponent }
]
@NgModule({
  declarations: [
    AppComponent,
    ContactComponent,
    AccountComponent,
    MyCutsompipe
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(myRoute)
  ],
  exports: [],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
